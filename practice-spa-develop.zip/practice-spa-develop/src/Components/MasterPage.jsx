import React from 'react';

export default() => (
  <div className="jumbotron text-center">
    <h2>CANCER PREDICTOR</h2>
    <p>Why go near doctor when i'm there ?</p>
    <form className="form-inline">
    </form>
  </div>
);