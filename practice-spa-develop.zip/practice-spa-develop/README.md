# practice-spa

### Environment variables

- REACT_APP_API_HOST=`http://localhost:4001`   ##Practice_API container's port##
 
### Deployment instructions

- Node version: `12.20.1`
- Build command: `npm install`
- Start command: `npm run start`
- Port exposed: `3000`
